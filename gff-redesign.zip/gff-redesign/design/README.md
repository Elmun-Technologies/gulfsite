# GFF Uzbekistan — dizayn manbasi

- `*.dc.html` — har bir sahifaning dizayn manbasi (inline style’lar = aniq qiymatlar). Kod uchun referens, to‘g‘ridan-to‘g‘ri ishlatilmaydi.
- `Styleguide.dc.html` — tokenlar, komponentlar, animatsiya qoidalari.
- `Header.dc.html`, `Footer.dc.html` — umumiy komponentlar (`lang`, `active`, `count` props).
- `*.mobile.dc.html` — 390px ko‘rinish (desktop sahifaning o‘zi, alohida layout emas).
- `Main.ru.dc.html` — RU matnlar namunasi.
- `assets/` — rasmlar. Mijoz fotolari: warehouse, pack-*. Brend: monogram-*. Qolganlari — Unsplash (bepul litsenziya).
- `canvas.json` — sahifalar ro‘yxati va o‘lchamlari.
